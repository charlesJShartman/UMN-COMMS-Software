#include <gtest/gtest.h>
#include <packet/ppp_packet.h>

TEST(PPP, random_unwrap) {
    srand(time(NULL));

    udp::UnwrappedPacket unwrapped_udp_packet {};

    unwrapped_udp_packet.header_ = {};
    unwrapped_udp_packet.header_.length = 0;
    unwrapped_udp_packet.header_.destination_port = 50000;
    unwrapped_udp_packet.header_.source_port_and_packet_type = 50000;
    unwrapped_udp_packet.header_.sequence_number = 0;
    unwrapped_udp_packet.header_.time = static_cast<uint16_t>(time(NULL));

    uint16_t length {};

    uint16_t num_packets = 1000;
    uint16_t maximum_length = 30000;

    for (uint16_t i = 0; i < num_packets; i++) {
        unwrapped_udp_packet.data_payload_ = {};
        length = rand() % maximum_length + 1;
        for (uint16_t i = 0; i < length; i++)
            unwrapped_udp_packet.data_payload_.push_back(static_cast<std::byte>(rand() % 256));

        udp::Packet original_packet {unwrapped_udp_packet};
        ppp::Packet wrapped_packet {original_packet};
        udp::Packet final_packet {wrapped_packet.unwrap()};

        EXPECT_EQ(original_packet, final_packet);
    }
}

int main(int argc, char *argv[]) {
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}
