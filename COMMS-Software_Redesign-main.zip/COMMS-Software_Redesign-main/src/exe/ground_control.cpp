#include "util/uart.h"
#include "comms_hardware.h"

#include <stdint.h>
#include <iostream>

UART serial {comms::ports::GROUND_COMMAND_PORT, UART::disableHardwareFlowControl(UART::emptySettings(B115200))};

enum input : int {
    RADIOON = 1,
    RADIOOFF = 2,
};

void sendCommand(uint8_t command[]) {
    uint8_t response[64] {};
    if (serial.write(command, size_t {command[0]} + 1) <= 0)
        std::cerr << "No bytes sent" << std::endl;
    for (int i = 0; i < 5; i++) {
        sleep(1);
        if (serial.read(response, 64) > 0)
            return;
    }
    std::cerr << "No bytes received" << std::endl;
}

void chooseCommand(int command_id) {
    if (command_id == input::RADIOON) {
        uint8_t command[] = {16, 101, 1, 105, 1, 1, 10, 125, 0, 0, 8, 0, 0, 0, 0, 0, 0};
        sendCommand(command);
    } else if (command_id == input::RADIOOFF) {
        uint8_t command[] = {2, 101, 0};
        sendCommand(command);
    } else {
        exit(EXIT_SUCCESS);
    }
}

void print() {
    std::cout << "Radio On\t[1]" << std::endl;
    std::cout << "Radio Off\t[2]" << std::endl;
}

int main(){

    int choice;
    while (true) {
        print();
        std::cin >> choice;
        chooseCommand(choice);
    }
}
