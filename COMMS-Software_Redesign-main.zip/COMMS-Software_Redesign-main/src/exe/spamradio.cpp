#include <string>
#include <stdio.h>
#include <unistd.h>

#include "udp/socket.h"
#include "udp/udp.h"

int main(int argc, char* argv[]) {
    if (argc != 4) {
        std::cerr << "Usage: " << argv[0] << " <packet length> <time between sends (milliseconds)> <number of packets (0 for infinite)>\n" << std::endl;
        exit(1);
    }

    // get arguments
    uint16_t packet_length = atoi(argv[1]);
    uint32_t time_between_sends = atoi(argv[2]);
    size_t num_packets = atoi(argv[3]);


    std::string message;
    std::string num;
    udp::Socket sock = udp::Socket(subsystem_address::kWriteOnly);

    // create header
    udp::UnwrappedPacket unwrapped_packet {};
    unwrapped_packet.header_.time= time(NULL);
    unwrapped_packet.header_.destination_port = 40000;

    // create data
	uint8_t byte = 0;
	for(size_t i = 0; i < packet_length - sizeof(udp::PacketHeader); i++){
		unwrapped_packet.data_payload_.push_back(static_cast<std::byte>(byte));
        byte++;
	}

    udp::Packet wrapped_packet {unwrapped_packet};

    for (uint16_t i = 0; i < num_packets; i++) {
        sock.send_packet(wrapped_packet, subsystem_address::kcomsService);

        usleep(time_between_sends * 1000);

        unwrapped_packet.header_.sequence_number = i;
        unwrapped_packet.header_.time = time(NULL);

        wrapped_packet.setHeader(unwrapped_packet.header_);
    }

    return 0;
}
