#include "util/uart.h"

UART::UART(const std::string& port, struct termios options) {
    fd_ = open(port.c_str(), O_RDWR | O_NOCTTY | O_NONBLOCK);

    if (fd_ < 0)
        throw UARTException("Failed to open UART port");

    if (!isatty(fd_)) {
        close(fd_);
        throw UARTException("File specified is not a tty");
    }

    init_settings_ = getSettings();
    setSettings(options);
}

UART::~UART() {
    setSettings(init_settings_);
    close(fd_);
}

ssize_t UART::read(void *buf, size_t count) {
    uint8_t *buf_ = (uint8_t *) buf;
    ssize_t bytesRead {};

    bytesRead = ::read(fd_, buf_, count);

    return bytesRead;
}

size_t UART::write(const void *buf, size_t count) {
    uint8_t *buf_ = (uint8_t *) buf;
    ssize_t retVal;
    size_t bytesWritten = 0;
    size_t failed = 0;
    while (bytesWritten < count) {

        retVal = ::write(fd_, buf_ + bytesWritten, count - bytesWritten);
        if (retVal > 0) {
            bytesWritten += retVal;
        } else if (retVal < 0) {
            failed++;
            usleep(10000);
            if (failed > 5)
                throw UARTException("Failed to write to UART port");
        }
    }

    return bytesWritten;
}

void UART::flush() {
    if (tcflush(fd_, TCIOFLUSH) < 0)
        throw UARTException("Failed to flush UART port");
}

int UART::getFD() {
    return fd_;
}

struct termios UART::getSettings() {
    struct termios options;
    if (tcgetattr(fd_, &options) < 0)
        throw UARTException("Failed to get settings of UART port");
    return options;
}

void UART::setSettings(const struct termios &options) {
    if (tcsetattr(fd_, TCSANOW, &options) < 0)
        throw UARTException("Failed to set settings of UART port");
}
